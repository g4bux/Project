package org.example;

/**
 * Hello world!
 *
 */
public class Calculator
{
        public int sum(int a, int b) {
            return a + b;
        }
}
